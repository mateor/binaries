##### Please Note:
The __GUIDE__ document has [moved to a new location](https://github.com/commercialhaskell/stack/tree/master/doc/GUIDE.md).
The file you're viewing now remains as a pointer to the new file for a limited time.
Please update your personal links as needed.


*Maintainer note:*
*This file location was deprecated 2015 September; its planned removal date is 2016 January.*
